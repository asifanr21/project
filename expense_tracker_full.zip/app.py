from flask import Flask, g, jsonify, request, render_template, redirect, url_for, session
import sqlite3, os
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'data.db')

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = 'replace-this-with-a-secure-random-key'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
        db.row_factory = sqlite3.Row
    return db

def init_db():
    db = get_db()
    db.executescript(open(os.path.join(BASE_DIR, 'schema.sql')).read())
    cur = db.execute('SELECT COUNT(*) as c FROM users')
    if cur.fetchone()['c'] == 0:
        pw = generate_password_hash('password123')
        db.execute('INSERT INTO users (email, password, name) VALUES (?,?,?)', ('user@example.com', pw, 'Demo User'))
    cur = db.execute('SELECT COUNT(*) as c FROM transactions')
    if cur.fetchone()['c'] == 0:
        seeds = [
            ('Salary', 3200.00, 'Income', '2025-10-01', 'October salary', 1),
            ('Amazon Prime', -43.90, 'Subscription', '2025-10-05', 'Monthly subscription', 1),
            ('Groceries', -120.50, 'Food', '2025-10-10', 'Weekly groceries', 1),
            ('Uber', -15.20, 'Transport', '2025-10-12', 'Ride to office', 1),
            ('Freelance', 600.00, 'Income', '2025-09-20', 'Project payment', 1)
        ]
        for s in seeds:
            db.execute('INSERT INTO transactions (name, amount, category, date, notes, user_id) VALUES (?,?,?,?,?,?)', s)
    db.commit()

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def login_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login', next=request.path))
        return f(*args, **kwargs)
    return decorated

@app.route('/')
def root():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        db = get_db()
        cur = db.execute('SELECT * FROM users WHERE email=?', (email,))
        user = cur.fetchone()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        db = get_db()
        cur = db.execute('SELECT * FROM users WHERE email=?', (email,))
        if cur.fetchone():
            return render_template('signup.html', error='Email already registered')
        pw = generate_password_hash(password)
        db.execute('INSERT INTO users (email, password, name) VALUES (?,?,?)', (email, pw, name))
        db.commit()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', user_name=session.get('user_name'))

@app.route('/transactions')
@login_required
def transactions_page():
    return render_template('transactions.html')

@app.route('/settings')
@login_required
def settings_page():
    return render_template('settings.html')

# API endpoints
@app.route('/api/transactions', methods=['GET','POST'])
def api_transactions():
    if 'user_id' not in session:
        return jsonify({'error':'unauthorized'}), 401
    db = get_db()
    user_id = session['user_id']
    if request.method == 'GET':
        cur = db.execute('SELECT * FROM transactions WHERE user_id=? ORDER BY date DESC', (user_id,))
        rows = cur.fetchall()
        data = [dict(r) for r in rows]
        return jsonify(data)
    else:
        payload = request.get_json()
        db.execute('INSERT INTO transactions (name, amount, category, date, notes, user_id) VALUES (?,?,?,?,?,?)',
                   (payload.get('name'), float(payload.get('amount',0)), payload.get('category'), payload.get('date'), payload.get('notes'), user_id))
        db.commit()
        return jsonify({'status':'ok'}), 201

@app.route('/api/transactions/<int:tid>', methods=['PUT','DELETE'])
def api_transaction_modify(tid):
    if 'user_id' not in session:
        return jsonify({'error':'unauthorized'}), 401
    db = get_db()
    user_id = session['user_id']
    cur = db.execute('SELECT * FROM transactions WHERE id=? AND user_id=?', (tid, user_id))
    if not cur.fetchone():
        return jsonify({'error':'not found'}), 404
    if request.method == 'DELETE':
        db.execute('DELETE FROM transactions WHERE id=? AND user_id=?', (tid, user_id))
        db.commit()
        return jsonify({'status':'deleted'})
    else:
        payload = request.get_json()
        db.execute('UPDATE transactions SET name=?, amount=?, category=?, date=?, notes=? WHERE id=? AND user_id=?',
                   (payload.get('name'), float(payload.get('amount',0)), payload.get('category'), payload.get('date'), payload.get('notes'), tid, user_id))
        db.commit()
        return jsonify({'status':'updated'})

if __name__ == '__main__':
    if not os.path.exists(DB_PATH):
        with app.app_context():
            init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
