async function fetchTransactions(){
  const res = await fetch('/api/transactions');
  if (res.status === 401) { window.location='/login'; return []; }
  const data = await res.json();
  return data;
}

function renderList(items){
  const ul = document.getElementById('tx-list');
  ul.innerHTML = '';
  items.forEach(it => {
    const li = document.createElement('li');
    li.className = 'tx-item';
    li.innerHTML = `
      <div class="left">
        <strong>${it.name}</strong><br><small>${it.category || ''} · ${it.date || ''}</small>
      </div>
      <div class="right">
        <span class="amount">${it.amount.toFixed(2)}</span>
        <button class="del" data-id="${it.id}">Delete</button>
      </div>
    `;
    ul.appendChild(li);
  });

  document.querySelectorAll('.del').forEach(b=> b.addEventListener('click', async e=>{
    const id = e.target.dataset.id;
    await fetch('/api/transactions/' + id, {method:'DELETE'});
    load();
  }));
}

async function load(){
  const items = await fetchTransactions();
  renderList(items);
}

document.getElementById && document.getElementById('tx-form') && document.getElementById('tx-form').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const payload = {
    name: document.getElementById('name').value,
    amount: parseFloat(document.getElementById('amount').value),
    category: document.getElementById('category').value,
    date: document.getElementById('date').value,
    notes: document.getElementById('notes').value
  };
  await fetch('/api/transactions', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  e.target.reset();
  load();
});

load();
