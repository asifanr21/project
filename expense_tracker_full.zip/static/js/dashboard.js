async function fetchTransactions(){
  const res = await fetch('/api/transactions');
  if (res.status === 401) { window.location='/login'; return []; }
  const data = await res.json();
  return data;
}

function monthKey(d){
  const dt = new Date(d);
  return dt.getFullYear() + '-' + String(dt.getMonth()+1).padStart(2,'0');
}

async function render(){
  const items = await fetchTransactions();
  let income=0, expenses=0;
  items.forEach(it => {
    if (it.amount >= 0) income += it.amount;
    else expenses += it.amount;
  });
  document.getElementById('income').textContent = '$' + income.toFixed(2);
  document.getElementById('expenses').textContent = '$' + Math.abs(expenses).toFixed(2);
  document.getElementById('balance').textContent = '$' + (income+expenses).toFixed(2);

  const pieCtx = document.getElementById('pieChart').getContext('2d');
  new Chart(pieCtx, {
    type: 'doughnut',
    data: {
      labels: ['Income','Expenses'],
      datasets: [{ data: [income, Math.abs(expenses)], backgroundColor: ['#6c4eff','#ff6b6b'] }]
    }
  });

  const map = {};
  items.forEach(it => {
    if (!it.date) return;
    const k = monthKey(it.date);
    if (!map[k]) map[k]=0;
    map[k] += it.amount;
  });
  const keys = Object.keys(map).sort();
  const vals = keys.map(k=> map[k]);

  const lineCtx = document.getElementById('lineChart').getContext('2d');
  new Chart(lineCtx, {
    type: 'line',
    data: {
      labels: keys,
      datasets: [{ label: 'Net amount', data: vals, tension:0.3, fill:true }]
    },
    options: { scales: { y: { beginAtZero: true } } }
  });
}

render();
