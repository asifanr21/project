# Expense Tracker (Flask + Charts)

## Quick start
1. Unzip the project.
2. Create a venv and activate it.
3. `pip install -r requirements.txt`
4. `python app.py`
5. Open `http://127.0.0.1:5000` and login with `user@example.com` / `password123`

## What is included
- Login & Signup pages
- Dashboard with charts (income vs expense and monthly trend)
- Transactions management (add/delete/update)
- SQLite database auto-created with seed data
